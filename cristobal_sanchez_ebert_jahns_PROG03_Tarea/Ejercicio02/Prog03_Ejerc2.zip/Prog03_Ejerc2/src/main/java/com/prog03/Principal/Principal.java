/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.prog03.Principal;

//al no estar la clase en el mismo paquete se importa el paquete con la clase
import com.prog03.figuras.Rectangulo;

/**
 *
 * @author devi_
 */
public class Principal {
    public static void main(String[] args) {
        //instanciando objeto de la clase rectangulo 
        //se utiliza setter para asignar un valor inicial a los atributos
        //PRUEBA1-> Figura1 constructor vacio, con base y altura iguales
        Rectangulo Figura1 = new Rectangulo();
        Figura1.setAltura(10);
        Figura1.setBase(10);
        
        
        String figura;
        // si el valor booleano obtenido en el metodo isCuadrado() es true imprime es un cuadrado
        //en caso contrario imprime es un rectangulo
        if(Figura1.isCuadrado()){
            figura = "es un cuadrado";
        } else{
            figura = "es un rectangulo";  
        }
        
        //imprime en pantalla en el siguiente orden: cadena en formato largo
        // el area de la figura
        // si es un cuadrado o es un rectangulo
        System.out.println(Figura1.toString());
        System.out.println("el area del rectangulo es " +Figura1.getArea());
        System.out.println(figura + "\n");

        //PRUEBA2-> Figura2 constructor vacio, con base y altura diferentes
        Rectangulo Figura2 = new Rectangulo();
        Figura2.setAltura(5);
        Figura2.setBase(7);

        if (Figura2.isCuadrado()) {
            figura = "es un cuadrado";
        } else {
            figura = "es un rectangulo";
        }

        System.out.println(Figura2.toString());
        System.out.println("el area del rectangulo es " + Figura2.getArea());
        System.out.println(figura + "\n");
        
        
        //PRUEBA3-> Figura3 constructor que inicializa base y altura.
        //prueba con base y altura iguales
        Rectangulo Figura3 = new Rectangulo(5, 5);
        
        if (Figura3.isCuadrado()) {
            figura = "es un cuadrado";
        } else {
            figura = "es un rectangulo";
        }

        System.out.println(Figura3.toString());
        System.out.println("el area del rectangulo es " + Figura3.getArea());
        System.out.println(figura + "\n");
        
        
        //PRUEBA4-> Figura4 constructor que inicializa base y altura.
        //prueba con base y altura diferentes
        Rectangulo Figura4 = new Rectangulo(3, 5);
        
        if (Figura4.isCuadrado()) {
            figura = "es un cuadrado";
        } else {
            figura = "es un rectangulo";
        }

        System.out.println(Figura4.toString());
        System.out.println("el area del rectangulo es " + Figura4.getArea());
        System.out.println(figura + "\n");
        
    }
}
