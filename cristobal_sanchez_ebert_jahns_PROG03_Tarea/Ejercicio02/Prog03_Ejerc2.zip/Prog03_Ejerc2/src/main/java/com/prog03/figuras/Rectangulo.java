/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.prog03.figuras;

/**
 *
 * @author devi_
 */

//clase rectangulo
public class Rectangulo {
    
    //declaracion de atributos
    private float altura;
    private float base;

    //constructor vacío que inicialice los atributos a 0.
    public Rectangulo() {
        this.altura = 0;
        this.base = 0;
    }

    //constructor que inicialice base y altura.
    public Rectangulo(float altura, float base) {
        this.altura = altura;
        this.base = base;
    }

    //gettes  y setters que permitan acceder y modificar cada atributo   
    public double getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public double getBase() {
        return base;
    }

    public void setBase(float base) {
        this.base = base;
    }
    
    public float getArea(){
        return base*altura;
    }

    //método que devuelva una cadena conteniendo su área y su altura.
    @Override
    public String toString() {
        return "Figura{" + "altura=" + altura + ", base=" + base + '}';
    }
    
    // metodo booleano que indicando si el rectángulo es cuadrado.
    //se inicializa cuadrado con false indicando que no es un cuadrado 
    //pero si la base y altura son iguales entonces si es un cuadrado
    //y se retorna true o false dpendiendo si se cumple la condicion.
    public boolean isCuadrado() {
        boolean cuadrado = false;

        if (base == altura) {
            cuadrado = true;
        }    
        return cuadrado;
    }
    

    
    
    
    
}
