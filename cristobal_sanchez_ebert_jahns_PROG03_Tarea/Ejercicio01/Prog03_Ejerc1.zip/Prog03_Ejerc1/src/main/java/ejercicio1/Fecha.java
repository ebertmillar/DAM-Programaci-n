/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

/**
 *
 * @author devi_
 */

//·Crea una clase denominada Fecha. 
public class Fecha {
      
    //·Declara en el fichero de la clase un tipo enumerado, denominado enumMes, para los meses del año.
    public enum enumMes  {
        ENERO, FEBRERO, MARZO, ABRIRL, MAYO, JUNIO, JULIO, AGOSTO, SEPTIEMBRE, OCTUBRE, NOVIEMBRE, DICIEMBRE
    };
    
    //·La clase debe contener un atributo para el día, otro para mes (del tipo enumerado declarado) y un tercero para el año.
    private int dia;   
    public enumMes mes;
    private int año;    
      
    //·Implementa un constructor que inicialice el mes al valor recibido por parámetro y los demás atributos a 0
    public Fecha(enumMes mes) {
        this.dia = 0;
        this.mes = mes;
        this.año = 0;      
    }
    
    //·Declara otro constructor que inicialice todos los atributos de la clase.
    public Fecha(int dia, enumMes mes, int año) {
        this.dia = dia;
        this.mes = mes;
        this.año = año;
    }

    //·Implementa los métodos que permitan acceder y modificar cada uno de los atributos de la clase.
    //Getters y setters
    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public enumMes getMes() {
        return mes;
    }

    public void setMes(enumMes mes) {
        this.mes = mes;
    }
    
    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }
    
    //·Implementa un método que devuelva true si el valor contenido en la fecha es verano y false en caso contrario.
    public boolean isSummer() {

        boolean verano = false;

        if (mes == enumMes.JUNIO || mes == enumMes.JULIO || mes == enumMes.AGOSTO) {
            verano = true;
        }
        return verano;
    }

    //Implementa un método que devuelva una cadena con la fecha en formato largo,
    @Override
    public String toString() {
        return "la fecha es: " + dia + " de " + mes + " del " + año;
    }

}