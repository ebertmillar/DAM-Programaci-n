/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

/**
 *
 * @author devi_
 */
public class Principal {

    public static void main(String[] args) {

        //·Instancia un objeto de la clase Fecha denominado objFecha1 con el primer constructor.
        //·Actualiza los atributos dia y año para dicho objeto.
        Fecha objFecha1 = new Fecha(Fecha.enumMes.FEBRERO);
        objFecha1.setDia(20);
        objFecha1.setAño(2000);
        String mostrarFecha1 = objFecha1.toString();

        //Muestra un mensaje por pantalla indicando si la fecha es verano 
        //si el valor boleano obtenido en el mertodo isSumer() es true entonces va a imprimir es verano
        //caso contrario imprimira no es verano
        String estacion;
        
        if (objFecha1.isSummer()) {
             estacion = "Es verano";
        } else {
            estacion = "No es verano";
        }

        //·Muestra la fecha por pantalla en formato largo y si es verano o no.
        System.out.println("Primera fecha, inicializada con el primer constructor");
        System.out.println(mostrarFecha1);   
        System.out.println(estacion);
        

        //Instancia otro objeto de la clase Fecha denomiando objFecha2 con el segundo constructor.
        Fecha objFecha2 = new Fecha(15, Fecha.enumMes.JULIO, 2015);
        String mostrarFecha2 = objFecha2.toString();
        
        
        //Muestra un mensaje por pantalla indicando si la fecha es verano
        if (objFecha2.isSummer()) {
             estacion = "Es verano";
        } else {
            estacion = "No es verano";
        }
           
        //·Muestra la fecha por pantalla en formato largo y si es verano o no
        System.out.println("\nLa fecha 2 contiene el año 2015");
        System.out.println("Segunda fecha, inicializada con el segundo constructor");
        System.out.println(mostrarFecha2);   
        System.out.println(estacion);
    }

}
